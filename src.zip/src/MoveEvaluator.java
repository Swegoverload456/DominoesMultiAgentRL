package src;

import java.util.ArrayList;
import java.util.concurrent.Callable;

public class MoveEvaluator implements Callable<MoveResult> {
    private ArrayList<Tile> board;
    private ArrayList<Tile> playerHand;
    private Tile tile;
    private int leftEnd;
    private int rightEnd;
    private boolean playOnLeft;
    private ArrayList<Tile> remainingTiles; // Tiles not yet played or in any player's hand

    public MoveEvaluator(ArrayList<Tile> board, ArrayList<Tile> playerHand, Tile tile, int leftEnd, int rightEnd, boolean playOnLeft, ArrayList<Tile> remainingTiles) {
        this.board = new ArrayList<>(board);
        this.playerHand = new ArrayList<>(playerHand);
        this.tile = tile;
        this.leftEnd = leftEnd;
        this.rightEnd = rightEnd;
        this.playOnLeft = playOnLeft;
        this.remainingTiles = new ArrayList<>(remainingTiles);
    }

    public ArrayList<Tile> getRemainingTiles(ArrayList<Tile> board, ArrayList<Tile> playerTiles){
        Player temp = new Player();
        for(int i = 0; i < 7; i++){
            for(int j = 0; j <= i; j++){
                temp.add(new Tile(j, i));
            }
        }

        for(int i = 0; i < board.size(); i++){
            temp.remove(board.get(i).getA(), board.get(i).getB());
        }

        for(int i = 0; i < playerTiles.size(); i++){
            temp.remove(playerTiles.get(i).getA(), playerTiles.get(i).getB());
        }

        return temp.getHand();
    }

    @Override
    public MoveResult call() {
        // Simulate playing the tile
        ArrayList<Tile> newBoard = new ArrayList<>(board);
        ArrayList<Tile> newPlayerHand = new ArrayList<>(playerHand);
        newPlayerHand.remove(tile); // Remove the played tile from the player's hand
        remainingTiles = getRemainingTiles(newBoard, newPlayerHand);
        int newLeftEnd = leftEnd;
        int newRightEnd = rightEnd;
        playTile(newBoard, tile, playOnLeft, newLeftEnd, newRightEnd);

        // Evaluate the game state after playing this tile
        double winRate = simulateGame(newBoard, newPlayerHand, newLeftEnd, newRightEnd, 0, remainingTiles);

        // Return the result
        return new MoveResult(tile, winRate);
    }

    private void playTile(ArrayList<Tile> board, Tile tile, boolean playOnLeft, int leftEnd, int rightEnd) {
        if (playOnLeft) {
            if (tile.getA() == leftEnd) {
                board.add(0, new Tile(tile.getB(), tile.getA()));
                leftEnd = tile.getB();
            } else if (tile.getB() == leftEnd) {
                board.add(0, new Tile(tile.getA(), tile.getB()));
                leftEnd = tile.getA();
            }
        } else {
            if (tile.getA() == rightEnd) {
                board.add(new Tile(tile.getA(), tile.getB()));
                rightEnd = tile.getB();
            } else if (tile.getB() == rightEnd) {
                board.add(new Tile(tile.getB(), tile.getA()));
                rightEnd = tile.getA();
            }
        }
    }

    private double simulateGame(ArrayList<Tile> board, ArrayList<Tile> playerHand, int leftEnd, int rightEnd, int currentPlayer, ArrayList<Tile> remainingTiles) {
        // Base case: if the current player's hand is empty, they have won
        if (playerHand.size() == 1 && getPlayableTiles(playerHand, leftEnd, rightEnd).size() == 1) {
            return currentPlayer == 0 ? 1.0 : 0.0; // Player wins if it's their turn, otherwise they lose
        }

        // Base case: if the depth limit is reached, return a neutral win rate
        if (remainingTiles.isEmpty()) {
            return 0.5;
        }

        double totalWinRate = 0.0;
        int validMoves = 0;

        // Determine whose turn it is
        ArrayList<Tile> currentHand;
        if (currentPlayer == 0) {
            // Player's turn: use the player's hand
            currentHand = playerHand;
        } else {
            // Opponent's turn: simulate their hand using the remaining tiles
            currentHand = new ArrayList<>(remainingTiles);
            currentHand = getRemainingTiles(board, playerHand);
        }

        // Get the current player's playable tiles
        ArrayList<Tile> playableTiles = getPlayableTiles(currentHand, leftEnd, rightEnd);

        if (playableTiles.isEmpty()) {
            // If no valid moves, the current player passes
            return simulateGame(board, playerHand, leftEnd, rightEnd, (currentPlayer + 1) % 4, remainingTiles);
        }

        // Simulate each possible move
        for (Tile tile : playableTiles) {
            // Simulate playing the tile on the left end
            ArrayList<Tile> newBoard = new ArrayList<>(board);
            ArrayList<Tile> newPlayerHand = new ArrayList<>(playerHand);
            ArrayList<Tile> newRemainingTiles = new ArrayList<>(remainingTiles);
            remainingTiles = getRemainingTiles(newBoard, newPlayerHand);

            if (currentPlayer == 0) {
                // Player's turn: remove the tile from their hand
                newPlayerHand.remove(tile);
            } else {
                // Opponent's turn: remove the tile from the remaining tiles
                newRemainingTiles.remove(tile);
            }

            int newLeftEnd = leftEnd;
            int newRightEnd = rightEnd;
            playTile(newBoard, tile, true, newLeftEnd, newRightEnd);
            newRemainingTiles = getRemainingTiles(newBoard, newPlayerHand);
            // Recursively evaluate the game state after playing this tile
            double winRate = simulateGame(newBoard, newPlayerHand, newLeftEnd, newRightEnd, (currentPlayer + 1) % 4, newRemainingTiles);
            totalWinRate += winRate;
            validMoves++;

            // Simulate playing the tile on the right end
            newBoard = new ArrayList<>(board);
            newPlayerHand = new ArrayList<>(playerHand);
            newRemainingTiles = new ArrayList<>(remainingTiles);
            newRemainingTiles = getRemainingTiles(newBoard, newPlayerHand);

            if (currentPlayer == 0) {
                // Player's turn: remove the tile from their hand
                newPlayerHand.remove(tile);
            } else {
                // Opponent's turn: remove the tile from the remaining tiles
                newRemainingTiles.remove(tile);
            }

            newLeftEnd = leftEnd;
            newRightEnd = rightEnd;
            playTile(newBoard, tile, false, newLeftEnd, newRightEnd);
            newRemainingTiles = getRemainingTiles(newBoard, newPlayerHand);
            // Recursively evaluate the game state after playing this tile
            winRate = simulateGame(newBoard, newPlayerHand, newLeftEnd, newRightEnd, (currentPlayer + 1) % 4, newRemainingTiles);
            totalWinRate += winRate;
            validMoves++;
        }

        // Return the average win rate over all valid moves
        return totalWinRate / validMoves;
    }

    private ArrayList<Tile> getPlayableTiles(ArrayList<Tile> tiles, int leftEnd, int rightEnd) {
        ArrayList<Tile> playableTiles = new ArrayList<>();
        for (Tile tile : tiles) {
            if (canPlayTile(tile, leftEnd, rightEnd)) {
                playableTiles.add(tile);
            }
        }
        return playableTiles;
    }

    private boolean canPlayTile(Tile tile, int leftEnd, int rightEnd) {
        return (tile.getA() == leftEnd || tile.getB() == leftEnd || tile.getA() == rightEnd || tile.getB() == rightEnd);
    }
}