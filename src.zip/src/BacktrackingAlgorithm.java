package src;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.*;

public class BacktrackingAlgorithm {

    // Memoization cache to store evaluated game states
    public static final Map<String, Double> memo = new ConcurrentHashMap<>();

    public static ArrayList<Tile> getRemainingTiles(ArrayList<Tile> board, ArrayList<Tile> playerTiles){
        Player temp = new Player();
        for(int i = 0; i < 7; i++){
            for(int j = 0; j <= i; j++){
                temp.add(new Tile(j, i));
            }
        }

        for(int i = 0; i < board.size(); i++){
            temp.remove(board.get(i).getA(), board.get(i).getB());
        }

        for(int i = 0; i < playerTiles.size(); i++){
            temp.remove(playerTiles.get(i).getA(), playerTiles.get(i).getB());
        }

        return temp.getHand();
    }

    public static Tile bestMove(ArrayList<Tile> board, ArrayList<Tile> hand, int leftEnd, int rightEnd) {
        ExecutorService executor = Executors.newFixedThreadPool(Runtime.getRuntime().availableProcessors());
        List<Future<MoveResult>> futures = new ArrayList<>();

        // Submit tasks for each possible move
        for (Tile tile : hand) {
            if (canPlayTile(tile, leftEnd, rightEnd)) {
                futures.add(executor.submit(new MoveEvaluator(board, hand, tile, leftEnd, rightEnd, true, getRemainingTiles(board, hand))));
                futures.add(executor.submit(new MoveEvaluator(board, hand, tile, leftEnd, rightEnd, false, getRemainingTiles(board, hand))));
            }
        }

        // Find the best move from the results
        Tile bestTile = null;
        double maxWinRate = -1;

        for (Future<MoveResult> future : futures) {
            try {
                MoveResult result = future.get();
                System.out.println("TILE: " + result.getTile().toString() + "\tWR: " + result.getWinRate());
                if (result.getWinRate() > maxWinRate) {
                    maxWinRate = result.getWinRate();
                    bestTile = result.getTile();
                }
            } catch (InterruptedException | ExecutionException e) {
                e.printStackTrace();
            }
        }

        executor.shutdown();


        System.out.println("BEST TILE: " + bestTile.toString());
        // If no tile with a higher win rate is found, return the first playable tile
        if (bestTile == null) {
            for (Tile tile : hand) {
                if (canPlayTile(tile, leftEnd, rightEnd)) {
                    return tile;
                }
            }
        }

        return bestTile;
    }

    private static boolean canPlayTile(Tile tile, int leftEnd, int rightEnd) {
        return (tile.getA() == leftEnd || tile.getB() == leftEnd || tile.getA() == rightEnd || tile.getB() == rightEnd);
    }
}