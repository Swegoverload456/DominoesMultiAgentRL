package src;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

import org.deeplearning4j.nn.multilayer.MultiLayerNetwork;
import org.nd4j.linalg.api.ndarray.INDArray;
import org.nd4j.linalg.factory.Nd4j;

public class Solver {
    
    public static ArrayList<Tile> board = new ArrayList<>();
    public static Player player = new Player();
    public static int leftEnd = -1;
    public static int rightEnd = -1;

    public static final String RESET = "\033[0m";
    public static final String BLACK = "\033[0;30m";
    public static final String RED = "\033[0;31m";
    public static final String GREEN = "\033[0;32m";
    public static final String YELLOW = "\033[0;33m";
    public static final String BLUE = "\033[0;34m";
    public static final String PURPLE = "\033[0;35m";
    public static final String CYAN = "\033[0;36m";
    public static final String WHITE = "\033[0;37m";

    // Load the trained Q-network model
    private static MultiLayerNetwork qNetwork;
    static {
        try {
            qNetwork = MultiLayerNetwork.load(new File("dominoes_qnetworkMillion2.zip"), true);
            System.out.println("Q-network model loaded successfully.");
        } catch (IOException e) {
            System.err.println("Failed to load Q-network model: " + e.getMessage());
            qNetwork = null; // Handle gracefully if loading fails
        }
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.println("Enter your tiles 1 by 1 in the format [a:b]");
        for (int i = 0; i < 7; i++) {
            System.out.println("Enter tile: ");
            String[] t = sc.nextLine().strip().split(":");
            player.add(new Tile(Integer.parseInt(t[0]), Integer.parseInt(t[1])));
        }

        while (board.size() < 28) {
            sc.nextLine(); // Clear buffer
            System.out.println("Enter 'b' for board operation or 'p' for player operation:");
            String op = sc.nextLine().strip().toLowerCase();

            if (op.equals("b")) {
                System.out.println("Enter tile: ");
                String[] t = sc.nextLine().strip().split(":");
                while (t.length < 2) {
                    t = sc.nextLine().strip().split(":");
                }
                Tile temp = new Tile(Integer.parseInt(t[0]), Integer.parseInt(t[1]));
                
                int side = 0;
                if (leftEnd == rightEnd || 
                    (temp.getA() == leftEnd && temp.getB() == rightEnd && leftEnd != rightEnd) || 
                    (temp.getA() == rightEnd && temp.getB() == leftEnd && leftEnd != rightEnd)) {
                    System.out.println("Enter 'l' if you want to place your tile on the left\nEnter 'r' if you want to place your tile on the right: ");
                    String s = sc.nextLine().strip().toLowerCase();
                    if (s.equals("l")) side = 1;
                    else side = 2;
                }

                addToBoard(temp, side);
            } else if (op.equals("p")) {
                ArrayList<Tile> playableTiles = player.getPlayableTiles(leftEnd, rightEnd);
                Collections.sort(playableTiles);

                // Get Q-network suggestion if model is loaded
                String suggestedMove = getQNetworkSuggestion(player, board, leftEnd, rightEnd);
                System.out.println("Q-network suggests: " + CYAN + suggestedMove + RESET);

                System.out.println("Enter the index of the tile you want to play. You can only play: " + PURPLE + playableTiles.toString() + RESET);
                System.out.println("Player action: ");

                int play = -1;
                try {
                    play = sc.nextInt() - 1;
                } catch (Exception e) {
                    sc.nextLine(); // Clear invalid input
                }

                while (play < 0 || play >= playableTiles.size()) {
                    System.out.println("Please enter a valid number between 1 and " + playableTiles.size() + ".");
                    try {
                        play = sc.nextInt() - 1;
                    } catch (Exception e) {
                        sc.nextLine();
                    }
                }

                int side = 0;
                if (leftEnd == rightEnd || 
                    (playableTiles.get(play).getA() == leftEnd && playableTiles.get(play).getB() == rightEnd && leftEnd != rightEnd) || 
                    (playableTiles.get(play).getA() == rightEnd && playableTiles.get(play).getB() == leftEnd && leftEnd != rightEnd)) {
                    System.out.println("Enter 'l' if you want to place your tile on the left\nEnter 'r' if you want to place your tile on the right: ");
                    sc.nextLine(); // Clear buffer
                    String s = sc.nextLine().toLowerCase();
                    if (s.equals("l")) side = 1;
                    else side = 2;
                }

                addToBoard(playableTiles.get(play), side);
                player.remove(playableTiles.get(play).getA(), playableTiles.get(play).getB());
                System.out.println("Added your piece.");
            }

            System.out.println("\n\n---------------------------------------------------------------");
            System.out.println("\nBoard State: " + YELLOW + board.toString() + RESET);
            System.out.println("\n---------------------------------------------------------------");
        }

        sc.close();
    }

    // Method to get Q-network's suggested move with Q-value
    private static String getQNetworkSuggestion(Player player, ArrayList<Tile> board, int leftEnd, int rightEnd) {
        if (qNetwork == null) {
            return "Model not loaded";
        }

        // Preallocate state buffer
        double[] state = new double[490];
        player.getState(board, leftEnd, rightEnd, state); // Pass buffer to getState
        INDArray input = Nd4j.createFromArray(new double[][]{state});
        INDArray qValues = qNetwork.output(input);

        // Get valid actions
        boolean[] valid = player.getValidActions(leftEnd, rightEnd);

        // Mask invalid actions
        for (int i = 0; i < 57; i++) {
            if (!valid[i]) {
                qValues.putScalar(new int[]{0, i}, Double.NEGATIVE_INFINITY);
            }
        }

        // Find the best action and its Q-value
        int bestAction = qValues.argMax(1).getInt(0);
        double bestQValue = qValues.getDouble(0, bestAction);
        
        // Format the suggestion with Q-value
        if (bestAction == 56) {
            return String.format("Pass (Q: %.3f)", bestQValue);
        } else {
            int tileIdx = bestAction % 28;
            Tile tile = Game.allTiles.get(tileIdx);
            String side = (bestAction < 28) ? "Left" : "Right";
            return String.format("%s on %s (Q: %.3f)", tile.toString(), side, bestQValue);
        }
    }

    public static void addToBoard(Tile t, int side) {
        if (board.size() == 0) {
            board.add(new Tile(t.getA(), t.getB()));
            leftEnd = t.getA();
            rightEnd = t.getB();
            return;
        }

        if (side > 0) {
            if (side == 1) {
                if (t.getA() == leftEnd) {
                    board.add(0, new Tile(t.getB(), t.getA()));
                    leftEnd = t.getB();
                } else if (t.getB() == leftEnd) {
                    board.add(0, new Tile(t.getA(), t.getB()));
                    leftEnd = t.getA();
                } else {
                    board.add(0, new Tile(t.getA(), t.getB()));
                    leftEnd = t.getA();
                }
                return;
            } else if (side == 2) {
                if (t.getA() == rightEnd) {
                    board.add(board.size(), new Tile(t.getA(), t.getB()));
                    rightEnd = t.getB();
                } else if (t.getB() == rightEnd) {
                    board.add(board.size(), new Tile(t.getB(), t.getA()));
                    rightEnd = t.getA();
                } else {
                    board.add(board.size(), new Tile(t.getA(), t.getB()));
                    rightEnd = t.getB();
                }
                return;
            }
        }

        if (t.getA() == leftEnd || t.getB() == leftEnd) {
            if (t.getA() == leftEnd) {
                board.add(0, new Tile(t.getB(), t.getA()));
                leftEnd = t.getB();
            } else if (t.getB() == leftEnd) {
                board.add(0, new Tile(t.getA(), t.getB()));
                leftEnd = t.getA();
            } else {
                board.add(0, new Tile(t.getA(), t.getB()));
                leftEnd = t.getA();
            }
            return;
        }

        if (t.getA() == rightEnd || t.getB() == rightEnd) {
            if (t.getA() == rightEnd) {
                board.add(board.size(), new Tile(t.getA(), t.getB()));
                rightEnd = t.getB();
            } else if (t.getB() == rightEnd) {
                board.add(board.size(), new Tile(t.getB(), t.getA()));
                rightEnd = t.getA();
            } else {
                board.add(board.size(), new Tile(t.getA(), t.getB()));
                rightEnd = t.getB();
            }
            return;
        }
    }
}